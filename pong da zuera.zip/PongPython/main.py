import pygame
import sys
import random
import settings
import singleplayer

singleplayer.start_game()