import pygame
import sys
import random


# esse arquivo responsável por definir as variaveis globais
# que serão utilizadas entre arquivos

# é utilizado para impedir lag de audio
pygame.mixer.pre_init(44100, -16, 2, 512)
# inicializa o pygame
pygame.init()
clock = pygame.time.Clock()

# define algumas cores que serão utilizadas
bg_color = pygame.Color("#0D0A0B")
accent_color = pygame.Color("#E2FCEF")

# cria fonte para score
font = pygame.font.Font("fonts/RetroGaming.ttf", 32)

# define a altura e largura da janela
screen_width, screen_height = 1024, 600
screen = pygame.display.set_mode((screen_width, screen_height))

# define o titulo da janela
pygame.display.set_caption("Pong")

v = ["sounds/bakaa.wav", "sounds/oniichan.wav","sounds/boom.wav"] #oponente ganha
v2 = ["sounds/eh.wav", "sounds/yo.wav","sounds/pop.wav","sounds/ah.wav","sounds/oh.wav"] #colisão raquete
v3 = ["sounds/ara_ara.wav", "sounds/aha.wav","sounds/bang.wav"] #player ganha
#def randSound(n):
#	return int(n / 3) - 1    
#print(randSound( random.randint(3, 11) ))
def randSound(vetor, n):
	return vetor[int(n / 3) - 1]    

#print(randSound( random.randint(3, 11) ))

bg_color = pygame.Color("#040F0F")  # bg color
accent_color = (253, 255, 252)  # cor das letras e linha no meio
basic_font = pygame.font.Font("fonts/RetroGaming.ttf", 32)  # carrega a fonte
walltop_hit = pygame.mixer.Sound("sounds/patapata1.wav")
wallbottom_hit = pygame.mixer.Sound("sounds/patapata2.wav")
#player_score =  pygame.mixer.Sound("sounds/ara_ara.wav") 
#opp_score = pygame.mixer.Sound(randSound(random.randint(1, 10))) 
hit_sound = pygame.mixer.Sound("sounds/eh.wav")  

#hit_sound = pygame.mixer.Sound("sounds/patapata1.wav")  
#score_sound = pygame.mixer.Sound("sounds/ara_ara.wav")  
destroy_sound = pygame.mixer.Sound("sounds/bakaa.wav")  
button_sound = pygame.mixer.Sound("sounds/oniichan.wav") 





# cria uma linha para ser desenhada no meio da tela
middle_strip = pygame.Rect(screen_width/2 - 2, 0, 4, screen_height) 